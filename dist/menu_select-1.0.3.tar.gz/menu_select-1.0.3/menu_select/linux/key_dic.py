# Linux
key_dic = {
    
    "\x1b[A": "KeyUp",
    "A": "KeyUp",
    
    '\x1b[B': "KeyDown",
    'B': "KeyDown",
    
    '\x1b[D': "KeyLeft",
    'D': "KeyLeft",
    
    '\x1b[C': "KeyRight",
    'C': "KeyRight",   
    
    "\r": "Enter",
    
}

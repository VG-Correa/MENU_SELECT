#Windows
key_dic = {
    
    "b'\\x00'b'H'": "KeyUp",
    "b'\\xe0'b'H'": "KeyUp",
    
    "b'\\xe0'b'P'": "KeyDown",
    "b'\\x00'b'P'": "KeyDown",
    
    "b'\\x00'b'K'": "KeyLeft",
    "b'\\xe0'b'K'": "KeyLeft",
    
    "b'\\x00'b'M'": "KeyRight",
    "b'\\xe0'b'M'": "KeyRight",   
    
    "b'\\r'": "Enter",
    
    "b' '": "BackSpace"
    
}

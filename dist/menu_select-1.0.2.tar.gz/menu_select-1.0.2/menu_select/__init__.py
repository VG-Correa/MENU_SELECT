"""Menu Select - Uma biblioteca para criação de menus seletivos."""

__version__ = "0.1.0"
__author__ = "VG-Correa"
__email__ = "v.victorgabriel2014@gmail.com"


# Importe aqui as classes/funções que você quer expor
from .Menu_select import Menu_select